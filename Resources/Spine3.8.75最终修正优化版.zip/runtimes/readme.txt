All official Spine runtimes are available on GitHub.
Please visit our Git repository for the latest source code:
https://github.com/EsotericSoftware/spine-runtimes
Also see the runtime documentation:
http://esotericsoftware.com/spine-using-runtimes