## FreeType Distribution v2.9.1

### FreeType License
<pre>

The FreeType 2 font engine is copyrighted work and cannot be used
legally without a software license.  We provide the FreeType Engine
distribution under two mutually exclusive open-source licenses.

You must choose one of the two licenses described below, then obey all
its terms and conditions when using FreeType 2 in any of your projects or
products.

  - The FreeType License, which is similar to the original BSD license
    *with* an advertising clause that forces you to explicitly cite the
    FreeType project in your product's documentation, such as follows:

    Portions of this software are copyright (c) 2018 The FreeType
    Project (www.freetype.org).  All rights reserved.

    Full details provided at http://www.freetype.org/license.html

    or

  - The GNU General Public License version 2.
    http://www.gnu.org/licenses/gpl-2.0.txt

</pre>
